/**
 * why.js — /why command
 * Menjelaskan kenapa bot belum entry saat ini.
 * Dilengkapi pullback zone context dan AI Explanation dari Gemini (fail-safe).
 */

const { getAllTimeframes }  = require('../../market/data');
const { runStrategy }       = require('../../analysis/strategy');
const { getOverallBias }    = require('../../analysis/scanner');
const { checkBlacklist }    = require('../../analysis/blacklist');
const { calculateEnsemble } = require('../../analysis/ensemble');
const { detectPullback }    = require('../../analysis/pullback');
const { toWIB }             = require('../../utils/wib_time');
const { renderBanner }      = require('../../banner');

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function registerWhy(bot) {
  bot.command('why', async (ctx) => {
    const loading = await ctx.replyWithHTML('🔍 <i>Menganalisis kondisi market...</i>');
    try {
      const tfData  = await getAllTimeframes();
      const result  = runStrategy(tfData);
      const overall = getOverallBias(result.analysis);
      const minConf = parseInt(process.env.MIN_CONFIDENCE || '65');
      const wib     = toWIB();

      const reasons = [];
      const checks  = [];

      // ── Check 1: Trend alignment ──────────────────────────────────────────
      const h4Bull = result.analysis.h4.bias.includes('BUY');
      const h1Bull = result.analysis.h1.bias.includes('BUY');
      const h4Bear = result.analysis.h4.bias.includes('SELL');
      const h1Bear = result.analysis.h1.bias.includes('SELL');
      const aligned = (h4Bull && h1Bull) || (h4Bear && h1Bear);
      const direction = (h4Bull && h1Bull) ? 'BUY' : (h4Bear && h1Bear) ? 'SELL' : null;

      if (!aligned) {
        if (h4Bull && !h1Bull) {
          reasons.push('• H4 bullish tapi H1 belum konfirmasi — tunggu H1 berbalik naik');
          checks.push(`❌ Trend: H4 ${escapeHtml(result.analysis.h4.bias)}, H1 ${escapeHtml(result.analysis.h1.bias)} — belum searah`);
        } else if (h4Bear && !h1Bear) {
          reasons.push('• H4 bearish tapi H1 belum konfirmasi — tunggu H1 berbalik turun');
          checks.push(`❌ Trend: H4 ${escapeHtml(result.analysis.h4.bias)}, H1 ${escapeHtml(result.analysis.h1.bias)} — belum searah`);
        } else {
          reasons.push('• Arah trend H4 dan H1 berlawanan — market masih dalam transisi');
          checks.push(`❌ Trend: H4 ${escapeHtml(result.analysis.h4.bias)} vs H1 ${escapeHtml(result.analysis.h1.bias)}`);
        }
      } else {
        checks.push(`✅ Trend: H4 + H1 searah (${h4Bull ? 'BULLISH' : 'BEARISH'})`);
      }

      // ── Check 2: Spike / volatility ───────────────────────────────────────
      if (result.spikeRisk) {
        reasons.push(`• Volatilitas ekstrem — terlalu berbahaya untuk entry sekarang (${escapeHtml(result.volatility)})`);
        checks.push(`❌ Volatilitas: ${escapeHtml(result.volatility)} — spike risk aktif`);
      } else {
        checks.push(`✅ Volatilitas: ${escapeHtml(result.volatility)} — aman`);
      }

      // ── Check 3: Pullback zone (menggantikan M5 rejection) ────────────────
      let pullback = null;
      try {
        const pbDir  = direction || (h4Bull ? 'BUY' : 'SELL');
        const m5Data = tfData.m5 || [];
        if (m5Data.length >= 52) {
          pullback = detectPullback(m5Data, pbDir);
        }
      } catch { /* skip */ }

      if (pullback) {
        if (pullback.inZone) {
          checks.push(`✅ Pullback: Harga di zona pullback (${escapeHtml(pullback.zoneType)})`);
        } else {
          const distInfo = pullback.distance && parseFloat(pullback.distance) > 0
            ? ` — ${pullback.distance} pips dari zona ideal`
            : '';
          reasons.push(`• Harga belum mencapai zona pullback ideal${distInfo}`);
          checks.push(`❌ Pullback: ${escapeHtml(pullback.reason)}`);

          if (pullback.ema20) {
            const pbDir  = direction || 'BUY';
            const target  = pbDir === 'BUY' ? pullback.ema20 : pullback.ema20;
            checks.push(`   → Zona pullback: EMA20 <code>${pullback.ema20.toFixed(2)}</code> | EMA50 <code>${pullback.ema50.toFixed(2)}</code>`);
          }
        }
      } else if (!result.m5Entry?.valid) {
        const m5Reason = escapeHtml(result.m5Entry?.reason || 'tidak valid');
        reasons.push(`• Konfirmasi entry M5 belum terbentuk (${m5Reason})`);
        checks.push(`❌ Entry M5: ${m5Reason}`);
      } else {
        checks.push(`✅ Konfirmasi entry terpenuhi`);
      }

      // ── Check 4: Confidence ───────────────────────────────────────────────
      if (result.confidence > 0) {
        if (result.confidence < minConf) {
          reasons.push(`• Confidence ${result.confidence}% masih di bawah minimum — perlu konfirmasi teknikal lebih kuat`);
          checks.push(`❌ Confidence: ${result.confidence}% (butuh ${minConf}%)`);
        } else {
          checks.push(`✅ Confidence: ${result.confidence}% — cukup untuk entry`);
        }
      } else {
        const partialConf = (() => {
          const { h4, h1, m15 } = result.analysis;
          let s = 0;
          if (h4.bias.includes('STRONG')) s += 30; else if (h4.bias !== 'NEUTRAL') s += 20;
          if (h1.bias.includes('STRONG')) s += 25; else if (h1.bias !== 'NEUTRAL') s += 15;
          if (m15.bias !== 'NEUTRAL') s += 15;
          return Math.min(97, Math.max(10, s));
        })();
        if (partialConf < minConf) {
          reasons.push(`• Confidence parsial ${partialConf}% — perlu alignment multi-timeframe lebih kuat`);
          checks.push(`❌ Confidence parsial: ${partialConf}% (butuh ${minConf}%)`);
        } else {
          checks.push(`⚠️ Confidence parsial ${partialConf}% (perlu aligned dulu)`);
        }
      }

      // ── Check 5: Blacklist ────────────────────────────────────────────────
      const bl = checkBlacklist(tfData);
      if (bl.blocked) {
        bl.reasons.forEach(r => reasons.push(`• ${escapeHtml(r)}`));
        bl.reasons.forEach(r => checks.push(`❌ ${escapeHtml(r)}`));
      } else {
        checks.push(`✅ Market bersih — tidak ada berita/blacklist`);
      }

      // ── Ensemble score ────────────────────────────────────────────────────
      let ensembleSummary = null;
      if (aligned && !result.spikeRisk) {
        try {
          const ens     = calculateEnsemble(tfData, direction);
          ensembleSummary = ens;
          const minEns   = parseInt(process.env.ENSEMBLE_MIN_SCORE_AGGRESSIVE || '75');
          if (ens.totalScore < minEns) {
            reasons.push(`• Ensemble score ${ens.totalScore}/100 masih di bawah ${minEns} — tidak cukup konfirmasi strategi`);
            checks.push(`❌ Ensemble: ${ens.totalScore}/100 (butuh ${minEns}+)`);
          } else {
            checks.push(`✅ Ensemble: ${ens.totalScore}/100`);
          }
        } catch { /* skip */ }
      }

      // ── Gemini AI Explanation (fail-safe) ─────────────────────────────────
      let aiExplanation = null;
      const geminiKey   = process.env.GEMINI_API_KEY;
      if (geminiKey && geminiKey !== 'your_gemini_api_key_here') {
        try {
          const { GoogleGenerativeAI } = require('@google/generative-ai');
          const genAI = new GoogleGenerativeAI(geminiKey);
          const model = genAI.getGenerativeModel({
            model: process.env.GEMINI_MODEL || 'gemini-1.5-flash',
          });

          const prompt = [
            'Kamu adalah AI advisor untuk trading bot XAUUSD.',
            'Berikan penjelasan SINGKAT (maks 3 kalimat, bahasa Indonesia, casual) kenapa bot belum entry sekarang.',
            '',
            `Kondisi saat ini:`,
            `- Bias overall: ${overall.label}`,
            `- H4: ${result.analysis.h4.bias}, H1: ${result.analysis.h1.bias}, M15: ${result.analysis.m15.bias}`,
            `- Aligned: ${aligned ? 'Ya' : 'Tidak'}`,
            `- Spike risk: ${result.spikeRisk ? 'Ya' : 'Tidak'}`,
            `- Pullback zone: ${pullback ? (pullback.inZone ? 'aktif' : pullback.reason) : 'tidak dicek'}`,
            `- Confidence: ${result.confidence}%`,
            `- Blacklist: ${bl.blocked ? bl.reasons.join(', ') : 'bersih'}`,
            '',
            'Jawab dalam 2-3 kalimat saja. Jangan pake bullet points.',
          ].join('\n');

          const aiRes = await model.generateContent(prompt);
          aiExplanation = aiRes.response.text().trim();
        } catch { /* fail-safe — skip AI jika error */ }
      }

      await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});

      const reasonCount = reasons.length;
      const isWaiting   = reasonCount > 0;

      const lines = [
        `━━━━━━━━━━━━━━━━━━`,
        `🔍 <b>AZZAVISION AI — KENAPA BELUM ENTRY?</b>`,
        `━━━━━━━━━━━━━━━━━━`,
        ``,
        wib.line,
        ``,
        `📊 <b>Pair</b>: XAUUSD | <b>Bias</b>: ${escapeHtml(overall.label)}`,
        ``,
        `━━━━━━━━━━━━━━━━━━`,
        ``,
      ];

      if (!isWaiting) {
        lines.push(`✅ <b>Semua syarat sudah terpenuhi!</b>`);
        lines.push(`Bot akan kirim sinyal sebentar lagi jika harga konfirmasi.`);
      } else {
        lines.push(`⏳ <b>Bot sedang menunggu ${reasonCount} kondisi:</b>`);
        reasons.forEach(r => lines.push(escapeHtml(r)));
      }

      lines.push(``);
      lines.push(`━━━━━━━━━━━━━━━━━━`);
      lines.push(`📋 <b>Detail kondisi:</b>`);
      checks.forEach(c => lines.push(c));

      if (ensembleSummary && ensembleSummary.ranking && ensembleSummary.ranking.length > 0) {
        lines.push(``);
        lines.push(`━━━━━━━━━━━━━━━━━━`);
        lines.push(`🏆 <b>Setup terkuat saat ini:</b>`);
        const rankEmoji = ['🥇','🥈','🥉'];
        ensembleSummary.ranking.slice(0, 3).forEach((r, i) => {
          lines.push(`${rankEmoji[i] || '•'} ${escapeHtml(r.name)}: <code>${r.confidence}%</code>`);
        });
      }

      if (aiExplanation) {
        lines.push(``);
        lines.push(`━━━━━━━━━━━━━━━━━━`);
        lines.push(`🤖 <b>AI Advisor:</b>`);
        lines.push(escapeHtml(aiExplanation));
      }

      lines.push(``);
      lines.push(`━━━━━━━━━━━━━━━━━━`);
      lines.push(`⚡ <i>AZZAVISION AI v3.1 | Analysis Engine</i>`);

      // Banner PNG: checklist visual dari `checks` (baris ✅/❌, skip sub-baris indent)
      try {
        const checklist = checks
          .filter((c) => !c.startsWith('   '))
          .map((c) => ({
            pass: c.startsWith('✅'),
            label: c.replace(/^✅|^❌|^⚠️/, '').trim().replace(/<[^>]+>/g, ''),
          }));
        const buffer = await renderBanner('why_not_entry', { pair: 'XAUUSD', checklist });
        await ctx.replyWithPhoto({ source: buffer });
      } catch (bannerErr) {
        console.error('[WHY-BANNER] Gagal render banner:', bannerErr.message);
      }

      await ctx.replyWithHTML(lines.join('\n'));
    } catch (err) {
      await ctx.telegram.deleteMessage(ctx.chat.id, loading.message_id).catch(() => {});
      await ctx.replyWithHTML(`❌ Gagal analisis.\n<code>${escapeHtml(err.message)}</code>`);
    }
  });
}

module.exports = { registerWhy };
